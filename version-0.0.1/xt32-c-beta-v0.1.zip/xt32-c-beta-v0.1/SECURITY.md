# Security Policy
2020 FiveNineDark Security Policy for xt32

## Supported Versions

Versions that are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
|  b0.1   | :x:                | 
|  b0.2   | :x:                |
|  b0.3   | :x:                |
|  1.0    | :white_check_mark: |
--------------------------------

## Reporting a Vulnerability

How to report Vulns in our programs!

You can email our team at contact@fiveninedark.com, expect update's within the first 24hours.
reported vulnerability's can be  accepted or declined, due to what the issues will include.
